# 백엔드 테스트 검증 산출물

이 디렉터리는 `AI_USAGE.md`에 제시할 수 있는 백엔드 검증 결과를 실행일별로 보관한다.
자동 테스트와 실제 외부 API 검증을 구분하며, 비밀키·인증 헤더·계약 원문·외부 원시
응답은 저장하지 않는다.

## 최신 실행

- [2026-08-01 백엔드 자동 검증](2026-08-01/SUMMARY.md)

## 증빙 구분

| 구분 | 의미 |
| --- | --- |
| `AUTOMATED_OFFLINE` | 외부 Adapter를 mock으로 고정한 일반 테스트·정적 검사·고정 fixture 평가 |
| `LIVE_EXTERNAL` | 명시적 승인 아래 실제 Upstage·Solar·Supabase 등을 호출한 별도 검증 |

실행일 폴더의 JUnit XML과 JSON은 기계 판독용 원본 산출물이고, `SUMMARY.md`는 제출·리뷰용
요약이다. 기존 live 결과는 실행일 폴더의 `live-integration-summary.md`에서 원본 문서로
연결한다.

## 재현 원칙

- 일반 `pytest`는 Supabase·Upstage·Modusign을 `mock`으로 강제한다.
- live 검증은 일반 테스트에 포함하지 않고 명시적인 확인 옵션이 있는 runner로만 실행한다.
- 실패하거나 실행하지 않은 검증은 통과로 기록하지 않는다.
- 새 실행은 기존 결과를 덮어쓰지 않고 날짜별 폴더로 추가한다.
